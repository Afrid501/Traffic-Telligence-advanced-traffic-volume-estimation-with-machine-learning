
import streamlit as st
import joblib
import numpy as np

# Load the trained model
model = joblib.load("traffic_volume_model.pkl")

st.title("Traffic Volume Estimator")

temp = st.number_input("Temperature (°C):")
rain = st.number_input("Rain (mm):")
clouds = st.slider("Cloud coverage (%)", 0, 100, 50)

if st.button("Predict"):
    features = np.array([[temp, rain, clouds]])
    prediction = model.predict(features)[0]
    st.success(f"Estimated Traffic Volume: {int(prediction)} vehicles")
